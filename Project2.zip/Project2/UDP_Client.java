import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Random;
import java.text.DecimalFormat;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class UDP_Client extends JFrame{
		private static int bufferSize = 100;

	   private static DatagramSocket socket;
	   public static int c=0;
	   public static int ack=1;
	   public static String r="1";
	   public static String msg="";
	   public static String old_msg="0";
	   
	   public static int ip1 = 0;
	   public static int ip2 = 0;
	   public static int ip3 = 0;
	   public static int ip4 = 0;
	   public static int g = 0;

	   private static DatagramSocket socketHR;
	   private static DatagramSocket socketLoc;
	   private static DatagramSocket socketAir;
	   private static DatagramSocket socketToxic;
	   
	   private static int indexHRRec = 0;
	   private static int indexHRSend = 0;
	   private static boolean isNewHR = false;
	   private static String bufferHR[] = new String[bufferSize];
	   
	   private static int indexLocRec = 0;
	   private static int indexLocSend = 0;
	   private static boolean isNewLoc = false;
	   private static String bufferLoc[] = new String[bufferSize];
	   
	   private static int indexAirRec = 0;
	   private static int indexAirSend = 0;
	   private static boolean isNewAir = false;
	   private static String bufferAir[] = new String[bufferSize];
	   
	   public static int indexToxicRec = 0;
	   private static int indexToxicSend = 0;
	   private static boolean isNewToxic = false;
	   private static String bufferToxic[] = new String[bufferSize];
	   	
	   
	 public static void main(String[] args) throws InterruptedException, IOException {

	     Thread hr = new Thread(new SensorHR());
	     hr.start();
	     Thread loc = new Thread(new SensorLoc());
	     loc.start();
	     Thread air = new Thread(new SensorAir());
	     air.start();
	     Thread toxic = new Thread(new SensorToxic());
	     toxic.start();

		   UDP_Client client=new UDP_Client();
		   Scanner s = new Scanner(System.in);
		   System.out.println("Enter IP with numbers separated by 'Enter' : ");
		   ip1=s.nextInt();
		   ip2=s.nextInt();
		   ip3=s.nextInt();
		   ip4=s.nextInt();
		   s.nextLine();
		   System.out.println("Enter Gremlin Function Value (0-100) : ");
		   g=s.nextInt();
		   //for demo handling
		   
		   while(c!=-1){ //have it set to stop sending packets once 100 are sent
			   Thread.sleep(40); //pause for readability
			   //System.out.println("Begin While Loop");
			
				//generating random values for sensors
				//Random rand = new Random(); 
				DecimalFormat two = new DecimalFormat("###.00");  
				//int tankLevel = client.getTankLevel();
				//int heartRate = client.getHeartRate();
				//double latitude = client.getLoc();
				
				
				msg = "";
				msg = "P" + c; //add the packet number
				
				//creating the message string based on sensors that have data
				boolean newData = false;
				if (indexHRRec != indexHRSend) {
					msg = msg + "" + bufferHR[indexHRSend];
					indexHRSend = incrementIndex(indexHRSend);
					newData = true;
				}
				if (indexAirRec != indexAirSend) {
					msg = msg + "" + bufferAir[indexAirSend];
					indexAirSend = incrementIndex(indexAirSend);
					newData = true;
				}
				if (indexLocRec != indexLocSend) {
					msg = msg + "" + bufferLoc[indexLocSend];
					indexLocSend = incrementIndex(indexLocSend);
					newData = true;
				}
				if (indexToxicRec != indexToxicSend) {
					msg = msg + "" + bufferToxic[indexToxicSend];
					indexToxicSend = incrementIndex(indexToxicSend);
					newData = true;
				}
				if (newData) {
					//adding message length header
					int length = msg.length() + 3;
					String lengthString = "";
					if (length < 10) {
						lengthString = "00" + length;
					} else if (length < 100) {
						lengthString = "0" + length;
					}
					else {
						lengthString = Integer.toString(length);
					}
					//adding length to message string
					//msg = lengthString + msg;
			
				  //saving old message in case we need to retransmit
				  old_msg=msg;
				  System.out.println("\n        Sending message packet: "+msg);
				  //sending packet
				  client.sendPacket();
				  //preparing to recieve ACK
				  r=client.readyToReceivPacket();
				  
				  c++;
			  }
			  
			  //while(r.trim().equals("0"))
			  //{
				  //System.out.println("Sending again");
				  //byte buff[]=old_msg.getBytes();
					
					//byte[] ipAddr = new byte[] { (byte)131, (byte)204, (byte)14, (byte)209};
					//InetAddress address = InetAddress.getByAddress(ipAddr);
					
					//DatagramPacket packetSend= new DatagramPacket(buff, buff.length, address, 10168);
					//socket.send(packetSend);
					//r=client.readyToReceivPacket();
			  //}
		   }
		 }
	
//function to send the packet
   public void sendPacket() throws InterruptedException{
	   UDP_Client rpacket=new UDP_Client();
	   try{
	         socket=new DatagramSocket();
	      }catch(SocketException ex){
	         System.exit(1);
	      }
	         try{
	        	
	            byte buff[]=msg.getBytes();
	            
	            byte[] ipAddr = new byte[] { (byte)ip1, (byte)ip2, (byte)ip3, (byte)ip4};
	            InetAddress addressT = InetAddress.getByAddress(ipAddr);
	            
	            //gremlin function to determin if the packet is dropped
				
				boolean gremlin = gremlinFunctionEthernet();
				if (gremlin == false) {
					System.out.println("Packet Number " + c + " Dropped!");
				}
				//if gremlin doesnt drop, then send it to the server
				else {
					DatagramPacket packetSend=
					   new DatagramPacket(buff, buff.length,
					   addressT, 10167);
					socket.send(packetSend);
				}
	       
	           }catch(IOException ex){
	            System.out.println(ex.getMessage());
	         }
   }
   
   public boolean gremlinFunctionEthernet() {
	   Random randSend = new Random();
		int gremlin = randSend.nextInt(100) + 1;
		if (gremlin < g) {
			return false;
		}
		//if gremlin doesnt drop, then send it to the server
		else {
			return true;
		}
	   
   }
   public String readyToReceivPacket() throws InterruptedException{
	   
	int counter = 0;
      while(true){
		  if(counter == 0) {
				  
			 try{
				byte buff1[]=new byte[128];
				DatagramPacket packet=
				new DatagramPacket(buff1,buff1.length);
				counter = 1;
				
				socket.setSoTimeout(40); //set timeout for if a packet is lost
				
				socket.receive(packet);
				
				String r_p_server=new String(packet.getData());
						           
				return r_p_server;

			 }catch(IOException ex){
					System.out.println(ex.getMessage());

			 }
			}
			else {//if a packet has been dropped, then here we resend it
				
		   UDP_Client client1=new UDP_Client();
				System.out.println("Resend!");
				client1.sendPacket();
				counter = 0;
			}
      }
  }  
   public static int incrementIndex(int indexIn) {
		indexIn = (indexIn + 1) % 100;
		return indexIn;
   }
	
   private static class SensorHR implements Runnable {
       public void run() {
	        System.out.println("Started HR Thread!");			 
			byte buff1[]=new byte[128];
			DatagramPacket packet = new DatagramPacket(buff1,buff1.length);			
	        try {
	 		   socketHR = new DatagramSocket(10160);
	
		      } catch (SocketException ex) {
		   	     System.out.println("Creating HR Socket FAILED...");
		         System.exit(1);
		      }
	
       	while(true) {
       		try {
					socketHR.receive(packet);
       		}
               catch(IOException ex){
      				 System.out.println(ex.getMessage());
      			 }
				//System.out.println("Recieved HR Num: " + indexHRRec);
				String hrData=new String(packet.getData());
				bufferHR[indexHRRec] = hrData;
				indexHRRec = incrementIndex(indexHRRec);
				//isNewHR = true;
				//packet = new DatagramPacket(buff1,buff1.length);
//				System.out.println("HR: " + r_p_server);     		
       	}
       }
   }	
   private static class SensorLoc implements Runnable {
       public void run() {
	        System.out.println("Started Loc Thread!");			 
			byte buff1[]=new byte[128];
			DatagramPacket packet = new DatagramPacket(buff1,buff1.length);			
	        try {
	 		   socketLoc = new DatagramSocket(10161);
	
		      } catch (SocketException ex) {
		   	     System.out.println("Creating Socket FAILED...");
		         System.exit(1);
		      }
	
       	while(true) {
       		try {
					socketLoc.receive(packet);
       		}
               catch(IOException ex){
      				 System.out.println(ex.getMessage());
      			 }
				//System.out.println("Recieved Loc Num: " + indexLocRec);
				String locData=new String(packet.getData());
				bufferLoc[indexLocRec] = locData;
				indexLocRec = incrementIndex(indexLocRec);
				isNewLoc = true;
				//packet = new DatagramPacket(buff1,buff1.length);
//				System.out.println("HR: " + r_p_server);     		
       	}
       }
   }	
   private static class SensorAir implements Runnable {
       public void run() {
	        System.out.println("Started Air Thread!");			 
			byte buff1[]=new byte[128];
			DatagramPacket packet = new DatagramPacket(buff1,buff1.length);			
	        try {
	 		   socketAir = new DatagramSocket(10162);
	
		      } catch (SocketException ex) {
		   	     System.out.println("Creating Socket FAILED...");
		         System.exit(1);
		      }
	
       	while(true) {
       		try {
					socketAir.receive(packet);
       		}
               catch(IOException ex){
      				 System.out.println(ex.getMessage());
      			 }
      			 
				//System.out.println("Recieved Air Num: " + indexAirRec);
				String airData=new String(packet.getData());
				bufferAir[indexAirRec] = airData;
				indexAirRec = incrementIndex(indexAirRec);
       	}
       }
   }	
   private static class SensorToxic implements Runnable {
       public void run() {
	        System.out.println("Started Toxic Thread!");			 
			byte buff1[]=new byte[128];
			DatagramPacket packet = new DatagramPacket(buff1,buff1.length);			
	        try {
	 		   socketToxic = new DatagramSocket(10163);
	
		      } catch (SocketException ex) {
		   	     System.out.println("Creating Socket FAILED...");
		         System.exit(1);
		      }
	
       	while(true) {
       		try {
					socketToxic.receive(packet);
       		}
               catch(IOException ex){
      				 System.out.println(ex.getMessage());
      			 }
				//System.out.println("Recieved Toxic Packet Num: " + indexToxicRec);
				
				String toxicData = new String(packet.getData());
				bufferToxic[indexToxicRec] = toxicData;
				indexToxicRec = incrementIndex(indexToxicRec);
				isNewToxic = true;
				//packet = new DatagramPacket(buff1,buff1.length);
				//System.out.println("Toxic: " + toxicData + "\n\n");     		
       	}
       }
   }

 
  

}

