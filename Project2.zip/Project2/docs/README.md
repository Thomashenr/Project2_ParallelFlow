# Wireless-Mobile
Project1 for Wireless and Mobile networkds

ports 10160 - 10169
	sensors: 		60-63
	client to server: 	64
